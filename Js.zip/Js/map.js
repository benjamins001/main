const fs = require('fs');
const cheerio = require('cheerio');

// Load HTML
const html = fs.readFileSync('page.html', 'utf8');
const $ = cheerio.load(html);

// Function to build CSS-style DOM path
function getDomPath(el) {
    let path = '';
    while (el && el.type === 'tag') {
        let tag = el.name;
        if (el.attribs.id) tag += `#${el.attribs.id}`;
        if (el.attribs.class) {
            const classes = el.attribs.class.trim().split(/\s+/).join('.');
            tag += `.${classes}`;
        }
        path = path ? `${tag} > ${path}` : tag;
        el = el.parent;
    }
    return 'html > ' + path;
}

// Extract DOM paths of all matching <a> elements
const paths = $('a[aria-label="business-link"]')
    .map((i, el) => getDomPath(el))
    .get();

// Save to file
fs.writeFileSync('link-structure.txt', paths.join('\n'), 'utf8');
console.log(`✅ Saved ${paths.length} DOM paths to link-structure.txt`);
