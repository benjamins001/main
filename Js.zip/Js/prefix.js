const fs = require('fs');

// Read res1.txt
let lines = fs.readFileSync('res1.txt', 'utf8')
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

// Remove spaces and prepend base URL
lines = lines.map(link => 'https://www.brownbook.net/' + link.replace(/\s+/g, ''));

// Save modified links back to file
fs.writeFileSync('res1.txt', lines.join('\n'), 'utf8');
console.log(`Prepended base URL to ${lines.length} links and saved to res1.txt`);
