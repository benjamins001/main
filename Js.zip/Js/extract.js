const fs = require('fs');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const pluginUserAgent = require('puppeteer-extra-plugin-anonymize-ua')();
const randomUseragent = require('random-useragent');

puppeteer.use(StealthPlugin());
puppeteer.use(pluginUserAgent);

const urls = fs.readFileSync('results1.txt', 'utf8')
  .split('\n')
  .map(line => line.trim())
  .filter(Boolean);

let proxies = fs.readFileSync('proxies.txt', 'utf8')
  .split('\n')
  .map(p => p.trim())
  .filter(Boolean);

let proxyIndex = 0;

function delay(min = 8000, max = 15000) {
  return new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * (max - min + 1)) + min));
}

async function simulateHumanInteraction(page) {
  const x = Math.random() * 500 + 100;
  const y = Math.random() * 300 + 100;
  await page.mouse.move(x, y, { steps: 10 });
  await page.mouse.click(x, y, { delay: Math.random() * 150 + 50 });

  const actions = ['ArrowDown', 'ArrowUp', 'ArrowRight'];
  const randomKey = actions[Math.floor(Math.random() * actions.length)];
  await page.keyboard.press(randomKey, { delay: Math.random() * 200 });
}

function parseProxy(proxyString) {
  const [auth, host] = proxyString.split('@');
  const [username, password] = auth.split(':');
  return { username, password, host };
}

(async () => {
  for (const url of urls) {
    let attempts = 0;
    let success = false;

    while (attempts < proxies.length && !success) {
      const proxy = proxies[proxyIndex % proxies.length];
      proxyIndex++;
      attempts++;

      const { username, password, host } = parseProxy(proxy);
      const userAgent = randomUseragent.getRandom();

      console.log(`\n🌐 Launching browser with proxy: ${proxy}`);

      const browser = await puppeteer.launch({
        headless: 'new',
        args: [
          `--proxy-server=http://${host}`,
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-blink-features=AutomationControlled'
        ]
      });

      const page = await browser.newPage();
      await page.setUserAgent(userAgent);
      await page.setViewport({
        width: Math.floor(Math.random() * 200) + 1024,
        height: Math.floor(Math.random() * 200) + 768
      });

      await page.authenticate({ username, password });

      page.on('console', msg => {
        if (msg.type() === 'error' || msg.type() === 'warning') {
          console.log(`⚠️ Browser log: ${msg.text()}`);
        }
      });

      try {
        console.log(`🔍 Visiting: ${url}`);
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

        let pageCount = 1;
        let seenUrls = new Set();

        while (true) {
          await simulateHumanInteraction(page);
          await delay();

          const links = await page.evaluate(() => {
            const result = [];
            const containers = document.querySelectorAll(
              'div.flex.grow.flex-wrap.shrink.items-center.justify-between.w-full'
            );
            containers.forEach(container => {
              const a = container.querySelector('a[aria-label="business-link"]');
              if (a && a.href) {
                result.push(a.href);
              }
            });
            return result;
          });

          const newLinks = links.filter(link => !seenUrls.has(link));

          if (newLinks.length > 0) {
            newLinks.forEach(link => seenUrls.add(link));
            fs.appendFileSync('re.txt', newLinks.join('\n') + '\n', 'utf8');
            console.log(`✅ Page ${pageCount}: Saved ${newLinks.length} new link(s)`);
          } else {
            console.log(`⚠️ Page ${pageCount}: No new links found`);
          }

          const nextButton = await page.$('button#nav-right-arrow');
          if (nextButton) {
            const isDisabled = await page.evaluate(btn => btn.disabled, nextButton);
            if (isDisabled) {
              console.log('⛔ Next button is disabled. End of pagination.');
              break;
            } else {
              await nextButton.click();
              pageCount++;
              console.log(`➡️ Navigating to page ${pageCount}...`);
              await delay();
            }
          } else {
            console.log('⛔ No next button found. End of pagination.');
            break;
          }
        }

        success = true;
      } catch (err) {
        console.error(`❌ Error on ${url} using proxy ${proxy}: ${err.message}`);
      } finally {
        await browser.close();
      }
    }
  }
})();