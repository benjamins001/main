const fs = require("fs");
const readline = require("readline");
const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
const cheerio = require("cheerio");

puppeteer.use(StealthPlugin());

async function extractLinksFromUrl(url, page) {
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
    const html = await page.content();
    const $ = cheerio.load(html);

    let links = [];

    // Target: <body> -> <div class="..."> -> <ul> -> <li> -> <a href>
    $("body div ul li a").each((_, el) => {
      const link = $(el).attr("href");
      if (link) {
        links.push(link);
      }
    });

    return links;
  } catch (err) {
    console.error(`❌ Error scraping ${url}:`, err.message);
    return [];
  }
}

async function main() {
  const fileStream = fs.createReadStream("re.txt");
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity,
  });

  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  const writeStream = fs.createWriteStream("result.txt", { flags: "a" });

  for await (const url of rl) {
    if (!url.trim()) continue;
    console.log(`🔍 Scraping: ${url}`);

    const links = await extractLinksFromUrl(url.trim(), page);

    for (const link of links) {
      writeStream.write(link + "\n");
      console.log("✅ Found:", link);
    }
  }

  await browser.close();
  writeStream.end();
  console.log("🎉 Extraction complete! Links saved to result.txt");
}

main();
