const fs = require('fs');

// Read and clean up keyword list
const keywords = fs.readFileSync('keywords.txt', 'utf8')
  .split('\n')
  .map(k => k.trim())
  .filter(k => k.length > 0);

// Read all lines from results1.txt
const lines = fs.readFileSync('results1.txt', 'utf8')
  .split('\n')
  .map(l => l.trim())
  .filter(l => l.length > 0);

// Create write stream for found.txt
const output = fs.createWriteStream('found.txt', { flags: 'w' });

// Search each line word by word
lines.forEach(line => {
  const wordsInLine = line.split(/\W+/); // Split on non-word characters (e.g., punctuation)
  for (const word of wordsInLine) {
    if (keywords.includes(word)) {
      output.write(line + '\n');
      break; // Avoid duplicate entries
    }
  }
});

output.end(() => {
  console.log('Search complete. Matches written to found.txt');
});
