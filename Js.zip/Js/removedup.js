const fs = require('fs');
const path = require('path');

// Path to your .txt file
const filePath = path.resolve(__dirname, 'results1.txt');

// Read the file
fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) return console.error('Error reading file:', err);

  // Split into lines and remove duplicates
  const lines = data.split(/\r?\n/);
  const uniqueLines = [...new Set(lines)].filter(line => line.trim() !== '');

  // Join the unique lines and write back to the same file
  fs.writeFile(filePath, uniqueLines.join('\n'), 'utf8', (err) => {
    if (err) return console.error('Error writing file:', err);
    console.log('Duplicates removed and file updated successfully.');
  });
});
