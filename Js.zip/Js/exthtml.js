const fs = require('fs');
const cheerio = require('cheerio');

// Load the HTML file
const html = fs.readFileSync('page.html', 'utf8');

// Load into Cheerio
const $ = cheerio.load(html);

// Selector chain based on provided structure
const links = [];

$('#app-layout.flex.flex-col.flex-1')
  .find('div.sm\\:mt-20.w-full.mx-auto.min-h-\\[calc\\(100vh\\+10px\\)\\]')
  .find('div.flex.flex-col.flex-wrap.w-full.items-center.justify-center.mt-60.px-12.sm\\:px-24.py-\\[30px\\].bg-\\[\\#F3F3F3\\]')
  .find('div.flex.flex-col.flex-wrap.w-full')
  .find('div.flex')
  .find('div.flex.flex-col.flex-wrap.w-full.bg-white.px-8.sm\\:px-40.py-10')
  .find('div.flex.w-full')
  .find('div.grid.grid-cols-2.xs\\:grid-cols-3.sm\\:grid-cols-4.gap-x-4.gap-y-8.w-full')
  .find('div.col-span-1')
  .each((i, el) => {
    const p = $(el).find('p.text-base.leading-normal.capitalize.truncate');
    const a = p.find('a');
    const href = a.attr('href');
    if (href) {
      links.push(href);
    }
  });

// Save to results.txt
fs.writeFileSync('results.txt', links.join('\n'), 'utf8');
console.log(`Extracted ${links.length} links to results.txt`);
