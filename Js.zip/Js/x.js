const fs = require('fs');
const cheerio = require('cheerio');

// Read pag.html
const html = fs.readFileSync('pag.html', 'utf8');
const $ = cheerio.load(html);

// Storage for hrefs
const links = [];

// Traverse the full path based on class structure
$('body')
  .find('div#__next')
  .find('div#app-layout')
  .find('div.flex.flex-1.flex-col.relative.overflow-hidden.z-\\[20\\]')
  .find('div.flex.flex-1.flex-col.relative.overflow-auto.z-\\[10\\]')
  .find('div.MuiContainer-root.MuiContainer-maxWidthLg.css-1qsxih2')
  .find('div.MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation1.rounded-8.shadow-1.p-20.sm\\:p-40.my-40.css-t5a33j')
  .find('div')
  .find('div.MuiGrid-root.MuiGrid-container.css-1d3bbye')
  .find('div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-12.MuiGrid-grid-sm-6.MuiGrid-grid-md-4.css-1twzmnh')
  .find('ul.MuiList-root.MuiList-padding.css-1ontqvh')
  .find('a')
  .each((i, el) => {
    const href = $(el).attr('href');
    if (href) links.push(href);
  });

// Save to res2.txt
fs.writeFileSync('res2.txt', links.join('\n'), 'utf8');
console.log(`✅ Extracted ${links.length} href(s) to res2.txt`);
