// Save this file as extractUrls.js

const fs = require('fs');
const readline = require('readline');
const puppeteer = require('puppeteer');

async function extractHrefFromPage(page, domPath) {
    try {
        await page.waitForSelector(domPath, { timeout: 10000 }); // wait up to 10s
        const href = await page.$eval(domPath, el => el.getAttribute('href'));
        return href;
    } catch (error) {
        console.error(`Could not extract href for this page: ${page.url()} - ${error.message}`);
        return null;
    }
}

(async () => {
    const inputFile = 'results1.txt';
    const outputFile = 'res1.txt';
    const domPath = 'body > div#app-layout.flex.flex-col.flex-1 > div.flex.flex-col.items-start.justify-center.w-full.max-w-[1240px].mx-auto.px-20.md:px-40.pt-10.sm:pt-20 > div.flex.flex-col.flex-wrap.justify-center.w-full > div.flex.gap-y-20.gap-x-60.flex-col.md:flex-row > div.w-full.max-sm:min-h-[100vh] > div > div.relative.bg-white.pt-10.pr-10.pb-16.flex.w-full.gap-12.sm:gap-40.max-sm:items-center.lg:container.flex-col.sm:flex-row. > div.w-full > div.flex.flex-col.justify-between.h-full.flex-wrap.w-full > div.pt-10.flex.justify-start.w-full > a.w-full.text-center.sm:w-auto.capitalize.bg-accent.text-white.text-[18px].hover:bg-accent\\/80.px-20.py-2\\.5.rounded-2xl';

    // Make sure the output file is empty before starting
    fs.writeFileSync(outputFile, '');

    const rl = readline.createInterface({
        input: fs.createReadStream(inputFile),
        crlfDelay: Infinity
    });

    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();

    for await (const url of rl) {
        if (!url.trim()) continue; // skip empty lines
        console.log(`Processing URL: ${url}`);

        try {
            await page.goto(url.trim(), { waitUntil: 'domcontentloaded', timeout: 30000 });

            const href = await extractHrefFromPage(page, domPath);

            if (href) {
                fs.appendFileSync(outputFile, href + '\n');
                console.log(`Extracted href: ${href}`);
            } else {
                console.log(`No href found for URL: ${url}`);
            }
        } catch (err) {
            console.error(`Error processing URL ${url}: ${err.message}`);
        }
    }

    await browser.close();
    console.log('Extraction complete.');
})();
