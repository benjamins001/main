const fs = require('fs');
const { JSDOM } = require('jsdom');

// Load the HTML file
const html = fs.readFileSync('page.html', 'utf-8');
const dom = new JSDOM(html);
const document = dom.window.document;

// Select by ID only (since the class has special characters)
const button = document.querySelector('#nav-right-arrow');

if (!button) {
  console.log('Button with id="nav-right-arrow" not found.');
  process.exit(0);
}

// Optionally verify class contains expected classes
const requiredClasses = [
  "inline-flex", "items-center", "justify-center", "h-[43px]", "px-16", "py-10",
  "text-2xl", "bg-accent", "text-white", "transition-all", "duration-250",
  "ease-in-out", "ml-20", "hover:bg-teal-700"
];

const classList = button.className.split(/\s+/);
const missing = requiredClasses.filter(cls => !classList.includes(cls));

if (missing.length > 0) {
  console.log('Warning: Button found but missing classes:', missing);
}

// Generate the DOM path
function getDomPath(el) {
  const path = [];
  while (el.parentElement) {
    let tag = el.tagName.toLowerCase();
    if (el.id) {
      tag += `#${el.id}`;
    } else if (el.className) {
      const classes = el.className.trim().split(/\s+/).filter(cls => !cls.includes('[') && !cls.includes(':')).join('.');
      if (classes) tag += `.${classes}`;
    }
    path.unshift(tag);
    el = el.parentElement;
  }
  return path.join(' > ');
}

// Print the path
console.log('DOM path to button:');
console.log(getDomPath(button));
