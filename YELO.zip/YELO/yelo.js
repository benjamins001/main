const fs = require("fs");
const axios = require("axios");
const cheerio = require("cheerio");

const BASE_URL = "https://www.yelo.hk";
const inputFile = "collected_links.txt"; // category pages you already collected
const outputFile = "company_links.txt"; // file to save company links

// Write stream (overwrite each run)
const stream = fs.createWriteStream(outputFile, { flags: "w" });

async function scrapeCategory(categoryUrl) {
    try {
        console.log("Visiting category:", categoryUrl);
        const { data } = await axios.get(categoryUrl);
        const $ = cheerio.load(data);

        // Collect unique /company/... links on the page
        const profileLinks = new Set();
        $('a[href^="/company/"]').each((i, el) => {
            const href = $(el).attr("href");
            if (href) {
                const fullUrl = new URL(href, BASE_URL).href;
                profileLinks.add(fullUrl);
            }
        });

        // Save immediately
        for (const link of profileLinks) {
            stream.write(link + "\n");
            console.log("   Found:", link);
        }
    } catch (err) {
        console.error("Error visiting category:", err.message);
    }
}

async function main() {
    const categoryLinks = fs.readFileSync(inputFile, "utf-8").split("\n").filter(Boolean);

    for (const link of categoryLinks) {
        await scrapeCategory(link);
    }

    stream.end();
    console.log(`✅ Finished. Company links saved to ${outputFile}`);
}

main();