// save this as extract.js
const fs = require("fs");
const readline = require("readline");

// Input file (change this to your text file path)
const inputFile = "cleanse.txt";

// Output files
const emailFile = "newsieveemails.txt";
const siteFile = "newsievelinks.txt";

// Create write streams
const emailStream = fs.createWriteStream(emailFile, { flags: "w" });
const siteStream = fs.createWriteStream(siteFile, { flags: "w" });

// Regex patterns
const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
const urlRegex = /(https?:\/\/[^\s]+)/g;

// Read file line by line
const rl = readline.createInterface({
    input: fs.createReadStream(inputFile),
    crlfDelay: Infinity,
});

rl.on("line", (line) => {
    // Extract emails
    const emails = line.match(emailRegex);
    if (emails) {
        emails.forEach((email) => emailStream.write(email + "\n"));
    }

    // Extract URLs
    const urls = line.match(urlRegex);
    if (urls) {
        urls.forEach((url) => siteStream.write(url + "\n"));
    }
});

rl.on("close", () => {
    emailStream.end();
    siteStream.end();
    console.log("✅ Extraction complete. Results saved in emails.txt and sitelinks.txt");
});