// remove-duplicates.js
const fs = require("fs");

// Read the file
const filePath = "HaiUAEemails1 copy.txt";
if (!fs.existsSync(filePath)) {
    console.log(`File not found: ${filePath}`);
    process.exit(1);
}

const lines = fs.readFileSync(filePath, "utf8")
    .split("\n")
    .map(l => l.trim())
    .filter(l => l.length > 0);

// Remove duplicates using a Set
const uniqueLines = [...new Set(lines)];

// Write back to the same file
fs.writeFileSync(filePath, uniqueLines.join("\n"), "utf8");

console.log(`✅ Removed duplicates. ${uniqueLines.length} unique entries saved to ${filePath}.`);