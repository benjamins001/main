// npm install puppeteer
const puppeteer = require("puppeteer");
const fs = require("fs");

(async() => {
    // Read all category URLs from list.txt
    const urls = fs.readFileSync("list.txt", "utf8")
        .split("\n")
        .map(l => l.trim())
        .filter(l => l.length > 0);

    // Launch Puppeteer with system Chrome
    const browser = await puppeteer.launch({
        headless: false,
        executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", // macOS Chrome path
        args: ["--no-sandbox", "--disable-setuid-sandbox"]
    });

    for (const searchUrl of urls) {
        console.log("🔎 Processing category:", searchUrl);

        const page = await browser.newPage();
        await page.goto(searchUrl, { waitUntil: "networkidle2", timeout: 60000 });

        let pageNum = 1;

        while (true) {
            console.log(`📄 Scraping page ${pageNum} of ${searchUrl}`);

            // Wait until websites load
            await page.waitForSelector("a.web-link span", { timeout: 20000 }).catch(() => {});

            // Extract website spans
            const websites = await page.$$eval("a.web-link span", (spans) =>
                spans.map(s => s.textContent.trim())
            );

            console.log(`✅ Found ${websites.length} websites on page ${pageNum}`);

            // Save to file
            for (let site of websites) {
                if (!site) continue;
                if (!site.startsWith("http")) {
                    site = "https://" + site.replace(/^\/+/, "");
                }
                fs.appendFileSync("weblinks.txt", site + "\n", "utf8");
                console.log("💾 Saved:", site);
            }

            // Check for "Next" button
            const nextBtn = await page.$("a.mob-pag-next");
            if (nextBtn) {
                console.log("➡️ Clicking Next...");
                await Promise.all([
                    page.click("a.mob-pag-next"),
                    page.waitForNavigation({ waitUntil: "networkidle2", timeout: 60000 })
                ]);
                pageNum++;
            } else {
                console.log("🚫 No more pages.");
                break;
            }
        }

        await page.close();
    }

    await browser.close();
    console.log("🎉 Done! All list.txt URLs processed.");
})();