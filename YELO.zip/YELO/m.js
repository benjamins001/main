const fs = require("fs");
const axios = require("axios");
const cheerio = require("cheerio");

const BASE_URL = "https://www.yelo.hk";
const START_PATH = "/category/general-business/1";
const outputFile = "collected_links.txt";

// Use a write stream so links save immediately
const stream = fs.createWriteStream(outputFile, { flags: "a" });

// Keep track of visited pages to avoid loops
const visited = new Set();

async function scrape(path) {
    const url = new URL(path, BASE_URL).href;

    if (visited.has(url)) {
        console.log("Already visited:", url);
        return;
    }

    try {
        console.log("Visiting:", url);
        visited.add(url);

        // Save immediately
        stream.write(url + "\n");

        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        // Find the "next" link
        const nextLink = $('a.pages_arrow[rel="next"]').attr("href");

        if (nextLink) {
            const nextUrl = new URL(nextLink, BASE_URL).href;
            if (!visited.has(nextUrl)) {
                await scrape(nextLink);
            } else {
                console.log("Next link already visited, stopping:", nextUrl);
            }
        } else {
            console.log("No more next links found.");
        }
    } catch (err) {
        console.error("Error scraping:", err.message);
    }
}

async function main() {
    await scrape(START_PATH);
    stream.end(); // close file after done
    console.log("✅ Finished scraping.");
}

main();