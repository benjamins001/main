const fs = require("fs");
const axios = require("axios");
const cheerio = require("cheerio");

async function extractEmailsFromPage(url, outputFile) {
    try {
        const response = await axios.get(url, {
            timeout: 10000,
            headers: { "User-Agent": "Mozilla/5.0" }
        });

        const $ = cheerio.load(response.data);

        $("a[href^='mailto:']").each((_, el) => {
            let email = $(el).attr("href").replace("mailto:", "").split("?")[0];
            if (/^[^@]+@[^@]+\.[^@]+$/.test(email)) {
                console.log(`📧 Found: ${email}`);
                fs.appendFileSync(outputFile, email + "\n", "utf-8");
            }
        });
    } catch (err) {
        console.log(`❌ Error fetching ${url}: ${err.message}`);
    }
}

async function main() {
    const inputFile = "HaiUAE1.txt"; // the list of links you generated
    const outputFile = "HaiUAEemails1.txt"; // where emails will be saved

    // clear old results
    fs.writeFileSync(outputFile, "");

    const links = fs.readFileSync(inputFile, "utf-8")
        .split("\n")
        .map(l => l.trim())
        .filter(Boolean);

    for (const link of links) {
        console.log(`🔎 Scraping: ${link}`);
        await extractEmailsFromPage(link, outputFile);
    }

    console.log(`\n✅ Done! Emails saved in ${outputFile}`);
}

main();