const fs = require("fs");
const axios = require("axios");
const cheerio = require("cheerio");

const inputFile = "company_links.txt"; // file with company profile links
const outputFile = "websites.txt"; // file to save websites

// Append mode
const stream = fs.createWriteStream(outputFile, { flags: "a" });

// Track visited companies to avoid duplicates
const visited = new Set();

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function scrapeCompany(url) {
    if (visited.has(url)) {
        console.log("Skipping already visited:", url);
        return;
    }
    visited.add(url);

    try {
        console.log("Visiting profile:", url);
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        // Grab company name (optional)
        const name = $("h1").first().text().trim();

        // Grab website link
        const website = $(".text.weblinks a").text().trim();

        if (website) {
            const line = name ? `${name} - ${website}\n` : `${website}\n`;
            stream.write(line);
            console.log("   Found:", line.trim());
        } else {
            console.log("   No website found for:", url);
        }
    } catch (err) {
        console.error("   Error:", err.message);
    }
}

async function main() {
    const companyLinks = fs.readFileSync(inputFile, "utf-8").split("\n").filter(Boolean);

    for (const link of companyLinks) {
        await scrapeCompany(link);
        await delay(500); // polite delay
    }

    stream.end();
    console.log(`✅ Done. Websites saved to ${outputFile}`);
}

main();