const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs");

const url = "https://www.bbc.com/news";

async function scrapeHeadlines() {
  try {
    // Fetch BBC News homepage
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    // Collect all headlines with data-testid="card-headline"
    const headlines = [];
    $("h2[data-testid='card-headline']").each((i, el) => {
      headlines.push($(el).text().trim());
    });

    if (headlines.length === 0) {
      throw new Error("No headlines found. BBC may have changed their structure.");
    }

    // Save into s.txt (first headline OR all headlines)
    fs.writeFileSync("s.txt", headlines.join("\n"), "utf8");

    console.log("✅ Headlines saved to s.txt");
  } catch (error) {
    console.error("❌ Error scraping:", error.message);
  }
}

scrapeHeadlines();
