// npm i puppeteer
const puppeteer = require("puppeteer");
const fs = require("fs");

(async () => {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  await page.goto("https://www.brownbook.net/business/49541435/imgdownloader", {
    waitUntil: "networkidle2",
    timeout: 60000,
  });

  try {
    // wait for email
    await page.waitForSelector("#business-email a, a[href^='mailto:']", { timeout: 20000 });

    const email = await page.$eval(
      "#business-email a, a[href^='mailto:']",
      (el) => (el.getAttribute("href") || "").replace(/^mailto:/, "").trim()
    );

    // wait for website link
    const website = await page.$eval(
      "#info-block a[href^='http']",
      (el) => el.getAttribute("href").trim()
    );

    const line = `${email} , ${website}\n`;

    // ✅ Append instead of overwrite
    fs.appendFileSync("s.txt", line, "utf8");

    console.log("✅ Saved to s.txt:", line);
  } catch (e) {
    console.error("❌ Could not find details:", e.message);
  }

  await browser.close();
})();
