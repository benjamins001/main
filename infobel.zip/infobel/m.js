// npm i puppeteer
const puppeteer = require("puppeteer");
const fs = require("fs");

(async () => {
  // Read all Infobel category URLs from list.txt
  const urls = fs.readFileSync("list.txt", "utf8")
    .split("\n")
    .map(l => l.trim())
    .filter(l => l.length > 0);

  const browser = await puppeteer.launch({ headless: false });

  for (const searchUrl of urls) {
    console.log("🔎 Processing category:", searchUrl);

    const page = await browser.newPage();
    await page.goto(searchUrl, { waitUntil: "networkidle2", timeout: 60000 });

    // Wait until customer boxes appear
    await page.waitForSelector("h2.customer-item-name a", { timeout: 20000 }).catch(() => {});

    // Get all business detail links
    const businessLinks = await page.$$eval("h2.customer-item-name a", (links) =>
      links.map(a => a.href).filter(h => h.includes("businessdetails.aspx"))
    );

    console.log(`✅ Found ${businessLinks.length} businesses on ${searchUrl}`);

    for (const businessUrl of businessLinks) {
      console.log("➡️ Visiting business:", businessUrl);

      const bizPage = await browser.newPage();
      await bizPage.goto(businessUrl, { waitUntil: "networkidle2", timeout: 60000 });

      try {
        // Extract Website link
        const website = await bizPage
          .$eval("a.detail-link[href^='http']", el => el.href)
          .catch(() => "N/A");

        if (website && website !== "N/A") {
          fs.appendFileSync("weblinks.txt", website + "\n", "utf8");
          console.log("✅ Saved website:", website);
        } else {
          console.log("⚠️ No website found for:", businessUrl);
        }
      } catch (e) {
        console.error("❌ Error extracting from:", businessUrl, e.message);
      }

      await bizPage.close();
    }

    await page.close();
  }

  await browser.close();
  console.log("🎉 Done! All list.txt URLs processed.");
})();
