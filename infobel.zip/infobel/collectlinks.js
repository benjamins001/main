// npm i puppeteer
const puppeteer = require("puppeteer");
const fs = require("fs");

(async () => {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  // Go to Infobel HK main page
  await page.goto("https://www.infobel.com/en/hongkong", {
    waitUntil: "networkidle2",
    timeout: 60000,
  });

  // Wait for dropdowns with categories to load
  await page.waitForSelector("a.category-search", { timeout: 20000 });

  // Extract all category and subcategory links
  const categoryLinks = await page.$$eval("a.category-search", (links) =>
    links.map((a) => a.href).filter((h) => h.includes("/business/"))
  );

  console.log(`✅ Found ${categoryLinks.length} category links`);

  // Save them into list.txt (one per line)
  fs.writeFileSync("list.txt", categoryLinks.join("\n"), "utf8");

  await browser.close();
  console.log("🎉 All category links saved to list.txt");
})();
